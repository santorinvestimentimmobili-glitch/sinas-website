SINAS - sito statico pronto per Vercel

Caricare questa cartella su GitHub e importare il repository in Vercel (Framework Preset: Other; nessun comando di build).

DA COMPLETARE PRIMA DELLA PUBBLICAZIONE DEFINITIVA:
1. Inserire il logo SINAS originale come logo-sinas.svg nella cartella principale oppure modificare i due riferimenti /logo-sinas.svg in index.html al percorso del logo effettivo.
2. Sostituire EMAIL_SINAS_DA_CONFERMARE con indirizzo ufficiale.
3. Collegare il dominio www.segreteriasinas.it nei settings Domains di Vercel, poi impostare DNS in Squarespace con i valori indicati da Vercel. Non cambiare i record MX delle email.

Il codice deriva dal blocco HTML SINAS originale recuperato, senza introdurre nuovi elementi grafici o funzionalita.
